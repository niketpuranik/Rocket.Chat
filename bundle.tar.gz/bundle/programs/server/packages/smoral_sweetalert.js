(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['smoral:sweetalert'] = {};

})();

//# sourceMappingURL=smoral_sweetalert.js.map
