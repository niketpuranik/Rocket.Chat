(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ECMAScript = Package.ecmascript.ECMAScript;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

(function(){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/rocketchat_sms/settings.js                                              //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
Meteor.startup(function () {                                                        // 1
	RocketChat.settings.addGroup('SMS', function () {                                  // 2
		this.add('SMS_Enabled', false, {                                                  // 3
			type: 'boolean'                                                                  // 4
		});                                                                               //
                                                                                    //
		this.add('SMS_Service', 'twilio', {                                               // 7
			type: 'select',                                                                  // 8
			values: [{                                                                       // 9
				key: 'twilio',                                                                  // 10
				i18nLabel: 'Twilio'                                                             // 11
			}],                                                                              //
			i18nLabel: 'Service'                                                             // 13
		});                                                                               //
                                                                                    //
		this.section('Twilio', function () {                                              // 16
			this.add('SMS_Twilio_fromNumber', '', {                                          // 17
				type: 'string',                                                                 // 18
				enableQuery: {                                                                  // 19
					_id: 'SMS_Service',                                                            // 20
					value: 'twilio'                                                                // 21
				},                                                                              //
				i18nLabel: 'From_Number'                                                        // 23
			});                                                                              //
			this.add('SMS_Twilio_Account_SID', '', {                                         // 25
				type: 'string',                                                                 // 26
				enableQuery: {                                                                  // 27
					_id: 'SMS_Service',                                                            // 28
					value: 'twilio'                                                                // 29
				},                                                                              //
				i18nLabel: 'Account_SID'                                                        // 31
			});                                                                              //
			this.add('SMS_Twilio_authToken', '', {                                           // 33
				type: 'string',                                                                 // 34
				enableQuery: {                                                                  // 35
					_id: 'SMS_Service',                                                            // 36
					value: 'twilio'                                                                // 37
				},                                                                              //
				i18nLabel: 'Auth_Token'                                                         // 39
			});                                                                              //
		});                                                                               //
	});                                                                                //
});                                                                                 //
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/rocketchat_sms/SMS.js                                                   //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
/* globals RocketChat */                                                            //
RocketChat.SMS = {                                                                  // 2
	enabled: false,                                                                    // 3
	services: {},                                                                      // 4
	accountSid: null,                                                                  // 5
	authToken: null,                                                                   // 6
	fromNumber: null,                                                                  // 7
                                                                                    //
	registerService: function (name, service) {                                        // 9
		this.services[name] = service;                                                    // 10
	},                                                                                 //
                                                                                    //
	getService: function (name) {                                                      // 13
		if (!this.services[name]) {                                                       // 14
			throw new Meteor.Error('error-sms-service-not-configured');                      // 15
		}                                                                                 //
		return new this.services[name](this.accountSid, this.authToken, this.fromNumber);
	}                                                                                  //
};                                                                                  //
                                                                                    //
RocketChat.settings.get('SMS_Enabled', function (key, value) {                      // 21
	RocketChat.SMS.enabled = value;                                                    // 22
});                                                                                 //
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/rocketchat_sms/services/twilio.js                                       //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
/* globals RocketChat */                                                            //
                                                                                    //
var Twilio = (function () {                                                         //
	function Twilio() {                                                                // 3
		babelHelpers.classCallCheck(this, Twilio);                                        //
                                                                                    //
		this.accountSid = RocketChat.settings.get('SMS_Twilio_Account_SID');              // 4
		this.authToken = RocketChat.settings.get('SMS_Twilio_authToken');                 // 5
		this.fromNumber = RocketChat.settings.get('SMS_Twilio_fromNumber');               // 6
	}                                                                                  //
                                                                                    //
	Twilio.prototype.parse = (function () {                                            // 2
		function parse(data) {                                                            // 8
			return {                                                                         // 9
				from: data.From,                                                                // 10
				to: data.To,                                                                    // 11
				body: data.Body,                                                                // 12
                                                                                    //
				extra: {                                                                        // 14
					toCountry: data.ToCountry,                                                     // 15
					toState: data.ToState,                                                         // 16
					toCity: data.ToCity,                                                           // 17
					toZip: data.ToZip,                                                             // 18
					fromCountry: data.FromCountry,                                                 // 19
					fromState: data.FromState,                                                     // 20
					fromCity: data.FromCity,                                                       // 21
					fromZip: data.FromZip                                                          // 22
				}                                                                               //
			};                                                                               //
		}                                                                                 //
                                                                                    //
		return parse;                                                                     //
	})();                                                                              //
                                                                                    //
	Twilio.prototype.send = (function () {                                             // 2
		function send(to, message) {                                                      // 26
			var client = Npm.require('twilio')(this.accountSid, this.authToken);             // 27
                                                                                    //
			client.messages.create({                                                         // 29
				to: to,                                                                         // 30
				from: this.fromNumber,                                                          // 31
				body: message                                                                   // 32
			});                                                                              //
		}                                                                                 //
                                                                                    //
		return send;                                                                      //
	})();                                                                              //
                                                                                    //
	return Twilio;                                                                     //
})();                                                                               //
                                                                                    //
RocketChat.SMS.registerService('twilio', Twilio);                                   // 37
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:sms'] = {};

})();

//# sourceMappingURL=rocketchat_sms.js.map
