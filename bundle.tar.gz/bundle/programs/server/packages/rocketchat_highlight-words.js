(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:highlight-words'] = {};

})();

//# sourceMappingURL=rocketchat_highlight-words.js.map
